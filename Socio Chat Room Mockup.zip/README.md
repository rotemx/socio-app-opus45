
  # Socio Chat Room Mockup

  This is a code bundle for Socio Chat Room Mockup. The original project is available at https://www.figma.com/design/E1uPBcQJI7Aul7B34eBBEg/Socio-Chat-Room-Mockup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  