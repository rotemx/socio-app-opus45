import { useState } from "react";
import { Users, Navigation } from "lucide-react";

const mockMapRooms = [
  { id: 1, name: "Coffee Lovers Unite ☕", members: 24, activeNow: 8, x: 25, y: 40 },
  { id: 2, name: "SF Tech Meetup", members: 156, activeNow: 32, x: 60, y: 30 },
  { id: 3, name: "Golden Gate Runners", members: 89, activeNow: 12, x: 45, y: 60 },
  { id: 4, name: "Photography Walk", members: 45, activeNow: 5, x: 70, y: 50 },
  { id: 5, name: "Dog Park Friends 🐕", members: 67, activeNow: 15, x: 30, y: 70 },
  { id: 6, name: "Late Night Eats", members: 112, activeNow: 28, x: 55, y: 45 },
];

export function MapView() {
  const [selectedRoom, setSelectedRoom] = useState<number | null>(null);
  const [hoveredRoom, setHoveredRoom] = useState<number | null>(null);

  const getActiveRoom = () => {
    if (selectedRoom) return mockMapRooms.find((r) => r.id === selectedRoom);
    if (hoveredRoom) return mockMapRooms.find((r) => r.id === hoveredRoom);
    return null;
  };

  const activeRoom = getActiveRoom();

  return (
    <div className="h-[calc(100vh-104px)] bg-white flex flex-col">
      {/* Map Container */}
      <div className="relative flex-1 bg-gradient-to-br from-gray-100 to-gray-200">
        {/* Grid pattern overlay */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(to right, #000 1px, transparent 1px),
              linear-gradient(to bottom, #000 1px, transparent 1px)
            `,
            backgroundSize: "40px 40px",
          }}
        />

        {/* Center marker (user location) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative">
            <div className="absolute inset-0 bg-blue-500 rounded-full animate-ping opacity-75"></div>
            <div className="relative w-3 h-3 bg-blue-500 rounded-full border-2 border-white shadow-lg"></div>
          </div>
        </div>

        {/* Room markers */}
        {mockMapRooms.map((room) => {
          const isSelected = selectedRoom === room.id;
          const isHovered = hoveredRoom === room.id;
          const isActive = isSelected || isHovered;

          return (
            <button
              key={room.id}
              onClick={() => setSelectedRoom(room.id === selectedRoom ? null : room.id)}
              onMouseEnter={() => setHoveredRoom(room.id)}
              onMouseLeave={() => setHoveredRoom(null)}
              className={`absolute group transition-all duration-300 ${
                isActive ? "z-20" : "z-10"
              }`}
              style={{
                left: `${room.x}%`,
                top: `${room.y}%`,
                transform: "translate(-50%, -50%)",
              }}
            >
              {/* Pulse ring */}
              {room.activeNow > 0 && (
                <div className="absolute inset-0 scale-150">
                  <div className={`absolute inset-0 rounded-full animate-ping ${
                    isActive ? "bg-purple-500" : "bg-gray-400"
                  } opacity-75`}></div>
                </div>
              )}

              {/* Marker */}
              <div
                className={`relative w-10 h-10 rounded-full border-[3px] flex items-center justify-center transition-all ${
                  isActive
                    ? "bg-gradient-to-br from-blue-500 to-purple-600 border-white scale-125 shadow-xl"
                    : "bg-white border-gray-300 shadow-md hover:scale-110"
                }`}
              >
                <Users className={`w-4 h-4 ${isActive ? "text-white" : "text-gray-600"}`} />
                
                {/* Active count badge */}
                {room.activeNow > 0 && (
                  <div className={`absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center text-[10px] font-medium ${
                    isActive
                      ? "bg-purple-500 text-white"
                      : "bg-blue-500 text-white"
                  }`}>
                    {room.activeNow}
                  </div>
                )}
              </div>
            </button>
          );
        })}

        {/* Recenter button */}
        <button className="absolute top-3 right-3 w-9 h-9 bg-white rounded-lg shadow-md border border-gray-100 flex items-center justify-center active:bg-gray-50 transition-colors">
          <Navigation className="w-[18px] h-[18px] text-gray-600" />
        </button>
      </div>

      {/* Room details panel */}
      {activeRoom && (
        <div className="px-4 py-3 bg-white border-t border-gray-100">
          <div className="flex items-center justify-between gap-3 mb-2">
            <div className="flex-1 min-w-0">
              <h3 className="text-[15px] font-medium text-gray-900 mb-0.5 truncate">{activeRoom.name}</h3>
              <div className="flex items-center gap-3 text-[12px] text-gray-500">
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {activeRoom.members}
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                  {activeRoom.activeNow} online
                </span>
              </div>
            </div>
          </div>
          <button className="w-full py-2.5 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-[15px] font-medium rounded-lg active:scale-[0.98] transition-transform">
            Join Room
          </button>
        </div>
      )}
    </div>
  );
}
