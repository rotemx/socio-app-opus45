import { MapPin, Bell, User } from "lucide-react";

export function Header() {
  return (
    <header className="bg-white sticky top-0 z-40 border-b border-gray-100">
      <div className="px-4 flex items-center justify-between h-[56px]">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <span className="text-white text-sm font-semibold">S</span>
          </div>
          <span className="text-[15px] font-semibold text-gray-900">Socio</span>
        </div>
        
        <div className="flex items-center gap-1">
          <button className="flex items-center gap-1 px-2 py-1.5 text-gray-600 active:bg-gray-100 rounded-lg transition-colors">
            <MapPin className="w-[18px] h-[18px]" />
            <span className="text-[13px]">SF</span>
          </button>
          
          <button className="relative p-2 text-gray-600 active:bg-gray-100 rounded-lg transition-colors">
            <Bell className="w-[20px] h-[20px]" />
            <span className="absolute top-1.5 right-1.5 w-[6px] h-[6px] bg-blue-500 rounded-full"></span>
          </button>
          
          <button className="p-2 text-gray-600 active:bg-gray-100 rounded-lg transition-colors">
            <User className="w-[20px] h-[20px]" />
          </button>
        </div>
      </div>
    </header>
  );
}
