import { Users, TrendingUp, ChevronRight } from "lucide-react";
import { WifiSignal } from "./WifiSignal";

interface ChatRoomCardProps {
  room: {
    id: number;
    name: string;
    distance: string;
    members: number;
    activeNow: number;
    category: string;
    description: string;
    trending: boolean;
  };
}

export function ChatRoomCard({ room }: ChatRoomCardProps) {
  return (
    <button className="w-full bg-white px-4 py-3 active:bg-gray-50 transition-colors text-left border-b border-gray-50 last:border-b-0">
      <div className="flex items-center gap-3">
        {/* Wifi Signal Icon */}
        <div className="flex-shrink-0">
          <WifiSignal distance={room.distance} />
        </div>

        {/* Room Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-0.5">
            <h3 className="text-[15px] text-gray-900 truncate font-medium">{room.name}</h3>
            {room.trending && (
              <TrendingUp className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
            )}
          </div>

          <p className="text-[13px] text-gray-500 mb-1.5 line-clamp-1">{room.description}</p>

          <div className="flex items-center gap-3 text-[12px] text-gray-400">
            <span className="flex items-center gap-1">
              <Users className="w-3 h-3" />
              {room.members}
            </span>
            <span>{room.distance}</span>
            {room.activeNow > 0 && (
              <span className="flex items-center gap-1 text-green-600">
                <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                {room.activeNow} online
              </span>
            )}
          </div>
        </div>

        {/* Arrow Icon */}
        <div className="flex-shrink-0">
          <ChevronRight className="w-5 h-5 text-gray-300" />
        </div>
      </div>
    </button>
  );
}
