import { Map, Compass, MessageCircle } from "lucide-react";

interface TabNavigationProps {
  activeTab: "discover" | "map" | "rooms" | "messages";
  onTabChange: (tab: "discover" | "map" | "rooms" | "messages") => void;
}

export function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  const tabs = [
    { id: "discover" as const, label: "Discover", icon: Compass },
    { id: "map" as const, label: "Map", icon: Map },
    { id: "rooms" as const, label: "Rooms", icon: MessageCircle },
  ];

  return (
    <nav className="bg-white sticky top-[56px] z-30 border-b border-gray-100">
      <div className="flex">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-3 relative ${
                isActive
                  ? "text-blue-500"
                  : "text-gray-500 active:text-gray-700"
              }`}
            >
              <Icon className="w-[18px] h-[18px]" />
              <span className="text-[13px] font-medium">{tab.label}</span>
              {isActive && (
                <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-blue-500" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
