import { Wifi } from "lucide-react";

interface WifiSignalProps {
  distance: string;
}

export function WifiSignal({ distance }: WifiSignalProps) {
  // Parse distance to determine signal strength
  const distanceValue = parseFloat(distance);
  
  // Determine signal strength (1-4 bars) based on distance
  let strength = 4;
  if (distanceValue > 1.5) {
    strength = 1;
  } else if (distanceValue > 1.0) {
    strength = 2;
  } else if (distanceValue > 0.5) {
    strength = 3;
  }

  return (
    <div className="relative w-5 h-5 flex items-center justify-center">
      {/* Base wifi icon */}
      <Wifi className="w-5 h-5 text-gray-300" />
      
      {/* Overlay with filled bars based on strength */}
      <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(${100 - (strength * 25)}% 0 0 0)` }}>
        <Wifi className={`w-5 h-5 ${
          strength === 4 ? "text-blue-500" :
          strength === 3 ? "text-blue-500" :
          strength === 2 ? "text-yellow-500" :
          "text-gray-400"
        }`} />
      </div>
    </div>
  );
}
