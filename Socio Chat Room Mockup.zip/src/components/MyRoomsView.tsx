import { Users, MessageCircle, Clock } from "lucide-react";

const myRooms = [
  {
    id: 1,
    name: "Coffee Lovers Unite ☕",
    lastMessage: "Has anyone tried the new cafe on Valencia?",
    unread: 3,
    members: 24,
    lastActive: "2m ago",
    role: "Member",
  },
  {
    id: 2,
    name: "SF Tech Meetup",
    lastMessage: "Tomorrow's meetup is still on at 6pm!",
    unread: 0,
    members: 156,
    lastActive: "15m ago",
    role: "Admin",
  },
  {
    id: 3,
    name: "Golden Gate Runners",
    lastMessage: "Great run this morning everyone!",
    unread: 7,
    members: 89,
    lastActive: "1h ago",
    role: "Member",
  },
];

export function MyRoomsView() {
  return (
    <div className="bg-white">
      <div>
        {myRooms.map((room) => (
          <button
            key={room.id}
            className="w-full px-4 py-3 active:bg-gray-50 transition-colors text-left border-b border-gray-50 last:border-b-0"
          >
            <div className="flex items-start gap-3">
              {/* Room Avatar */}
              <div className="w-11 h-11 bg-gradient-to-br from-gray-200 to-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
                <MessageCircle className="w-5 h-5 text-gray-600" />
              </div>

              {/* Room Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <div className="flex items-center gap-1.5 flex-1 min-w-0">
                    <h3 className="text-[15px] font-medium text-gray-900 truncate">{room.name}</h3>
                    {room.role === "Admin" && (
                      <span className="px-1.5 py-0.5 bg-blue-50 text-blue-600 text-[10px] font-medium rounded flex-shrink-0">
                        ADMIN
                      </span>
                    )}
                  </div>
                  <span className="text-[12px] text-gray-400 flex-shrink-0 ml-2">{room.lastActive}</span>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <p className="text-[13px] text-gray-500 truncate flex-1">{room.lastMessage}</p>
                  {room.unread > 0 && (
                    <div className="min-w-[18px] h-[18px] px-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-[11px] font-medium rounded-full flex items-center justify-center flex-shrink-0">
                      {room.unread}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Empty state for no rooms */}
      {myRooms.length === 0 && (
        <div className="text-center py-16 px-4">
          <div className="w-14 h-14 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3">
            <MessageCircle className="w-7 h-7 text-gray-400" />
          </div>
          <h3 className="text-[15px] font-medium text-gray-900 mb-1">No rooms yet</h3>
          <p className="text-[13px] text-gray-500 mb-6">Join chat rooms to start connecting</p>
          <button className="px-6 py-2.5 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-[15px] font-medium rounded-lg active:scale-[0.98] transition-transform">
            Discover Rooms
          </button>
        </div>
      )}
    </div>
  );
}
