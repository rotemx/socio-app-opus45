import { X } from "lucide-react";

interface FilterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const categories = [
  "All Categories",
  "Technology",
  "Food & Drink",
  "Fitness",
  "Arts",
  "Pets",
  "Music",
  "Gaming",
  "Sports",
];

const distances = ["Within 0.5 mi", "Within 1 mi", "Within 2 mi", "Within 5 mi", "Any distance"];

export function FilterModal({ isOpen, onClose }: FilterModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40" onClick={onClose}></div>

      {/* Modal */}
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3.5 flex items-center justify-between rounded-t-2xl">
          <h2 className="text-[17px] font-semibold text-gray-900">Filters</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full active:bg-gray-100 transition-colors flex items-center justify-center text-gray-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="px-4 py-4 space-y-5">
          {/* Distance Filter */}
          <div>
            <h3 className="text-[13px] font-medium text-gray-500 uppercase tracking-wide mb-2">Distance</h3>
            <div className="space-y-0.5">
              {distances.map((distance) => (
                <label
                  key={distance}
                  className="flex items-center gap-3 py-2 active:bg-gray-50 cursor-pointer transition-colors rounded-lg px-2 -mx-2"
                >
                  <input
                    type="radio"
                    name="distance"
                    defaultChecked={distance === "Within 2 mi"}
                    className="w-[18px] h-[18px] text-blue-500 cursor-pointer"
                  />
                  <span className="text-[15px] text-gray-900">{distance}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Category Filter */}
          <div>
            <h3 className="text-[13px] font-medium text-gray-500 uppercase tracking-wide mb-2">Category</h3>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  className="px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-full active:bg-gray-100 transition-colors text-[13px] text-gray-700"
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Activity Filter */}
          <div>
            <h3 className="text-[13px] font-medium text-gray-500 uppercase tracking-wide mb-2">Activity</h3>
            <div className="space-y-0.5">
              <label className="flex items-center gap-3 py-2 active:bg-gray-50 cursor-pointer transition-colors rounded-lg px-2 -mx-2">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-[18px] h-[18px] text-blue-500 rounded cursor-pointer"
                />
                <span className="text-[15px] text-gray-900">
                  Show only active rooms
                </span>
              </label>
              <label className="flex items-center gap-3 py-2 active:bg-gray-50 cursor-pointer transition-colors rounded-lg px-2 -mx-2">
                <input
                  type="checkbox"
                  className="w-[18px] h-[18px] text-blue-500 rounded cursor-pointer"
                />
                <span className="text-[15px] text-gray-900">
                  Show trending only
                </span>
              </label>
            </div>
          </div>

          {/* Room Size */}
          <div>
            <h3 className="text-[13px] font-medium text-gray-500 uppercase tracking-wide mb-2">Room Size</h3>
            <div className="space-y-2">
              <div>
                <label className="text-[13px] text-gray-600 mb-2 block">Minimum members</label>
                <input
                  type="range"
                  min="0"
                  max="200"
                  defaultValue="0"
                  className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
                <div className="flex justify-between text-[11px] text-gray-400 mt-1">
                  <span>0</span>
                  <span>200+</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-100 px-4 py-3 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 bg-gray-50 text-gray-700 text-[15px] font-medium rounded-lg active:bg-gray-100 transition-colors"
          >
            Reset
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-2.5 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-[15px] font-medium rounded-lg active:scale-[0.98] transition-transform"
          >
            Apply
          </button>
        </div>
      </div>
    </div>
  );
}
