import { Search, SlidersHorizontal, TrendingUp } from "lucide-react";
import { ChatRoomCard } from "./ChatRoomCard";

const mockRooms = [
  {
    id: 1,
    name: "Coffee Lovers Unite ☕",
    distance: "0.3 mi",
    members: 24,
    activeNow: 8,
    category: "Food & Drink",
    description: "For caffeine addicts in the Mission District",
    trending: true,
  },
  {
    id: 2,
    name: "SF Tech Meetup",
    distance: "0.5 mi",
    members: 156,
    activeNow: 32,
    category: "Technology",
    description: "Discuss startups, coding, and innovation",
    trending: true,
  },
  {
    id: 3,
    name: "Golden Gate Runners",
    distance: "0.8 mi",
    members: 89,
    activeNow: 12,
    category: "Fitness",
    description: "Morning and evening running crew",
    trending: false,
  },
  {
    id: 4,
    name: "Photography Walk",
    distance: "1.2 mi",
    members: 45,
    activeNow: 5,
    category: "Arts",
    description: "Weekly photo walks around the city",
    trending: false,
  },
  {
    id: 5,
    name: "Dog Park Friends 🐕",
    distance: "1.5 mi",
    members: 67,
    activeNow: 15,
    category: "Pets",
    description: "For dog owners in the neighborhood",
    trending: true,
  },
  {
    id: 6,
    name: "Late Night Eats",
    distance: "0.4 mi",
    members: 112,
    activeNow: 28,
    category: "Food & Drink",
    description: "Best spots for after-hours food",
    trending: false,
  },
];

interface DiscoverViewProps {
  onFilterClick: () => void;
}

export function DiscoverView({ onFilterClick }: DiscoverViewProps) {
  return (
    <div className="bg-white">
      {/* Search and Filter Bar */}
      <div className="px-4 pt-3 pb-2">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-[18px] h-[18px] text-gray-400" />
            <input
              type="text"
              placeholder="Search rooms..."
              className="w-full pl-10 pr-3 py-2 bg-gray-50 border-0 rounded-lg text-[15px] focus:outline-none focus:ring-1 focus:ring-blue-500 text-gray-900 placeholder-gray-400"
            />
          </div>
          <button
            onClick={onFilterClick}
            className="px-3 py-2 bg-gray-50 rounded-lg active:bg-gray-100 transition-colors flex items-center justify-center text-gray-600"
          >
            <SlidersHorizontal className="w-[18px] h-[18px]" />
          </button>
        </div>
      </div>

      {/* Trending Section */}
      <div className="mt-2">
        <div className="flex items-center gap-1.5 px-4 py-2 bg-gray-50">
          <TrendingUp className="w-[14px] h-[14px] text-blue-500" />
          <h2 className="text-[13px] text-gray-600 uppercase tracking-wide">Trending</h2>
        </div>
        <div>
          {mockRooms
            .filter((room) => room.trending)
            .map((room) => (
              <ChatRoomCard key={room.id} room={room} />
            ))}
        </div>
      </div>

      {/* All Nearby Rooms */}
      <div className="mt-4">
        <div className="flex items-center gap-1.5 px-4 py-2 bg-gray-50">
          <h2 className="text-[13px] text-gray-600 uppercase tracking-wide">Nearby</h2>
        </div>
        <div>
          {mockRooms.map((room) => (
            <ChatRoomCard key={room.id} room={room} />
          ))}
        </div>
      </div>
    </div>
  );
}
