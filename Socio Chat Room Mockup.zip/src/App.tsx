import { useState } from "react";
import { Header } from "./components/Header";
import { TabNavigation } from "./components/TabNavigation";
import { DiscoverView } from "./components/DiscoverView";
import { MapView } from "./components/MapView";
import { MyRoomsView } from "./components/MyRoomsView";
import { FilterModal } from "./components/FilterModal";

export default function App() {
  const [activeTab, setActiveTab] = useState<"discover" | "map" | "rooms" | "messages">("discover");
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      
      <div className="bg-white min-h-[calc(100vh-104px)]">
        {activeTab === "discover" && <DiscoverView onFilterClick={() => setIsFilterOpen(true)} />}
        {activeTab === "map" && <MapView />}
        {activeTab === "rooms" && <MyRoomsView />}
      </div>
      
      <FilterModal isOpen={isFilterOpen} onClose={() => setIsFilterOpen(false)} />
    </div>
  );
}
